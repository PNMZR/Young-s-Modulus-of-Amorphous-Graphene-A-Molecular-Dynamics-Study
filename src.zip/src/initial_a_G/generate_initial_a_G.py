# -*- coding: utf-8 -*-
"""
Generate 10 initial a-G samples with a particular vacancy concentration.

Before the execution of this code, you should set the values of variables
`count` (line 24) and `vacancy_percent` (line 25).

Rong Zhao (zhaorong@imech.ac.cn)
"""

import os
import shutil
import numpy as np
import math
from ovito.data import DataCollection, ParticleType, SimulationCell
from ovito.pipeline import Pipeline, StaticSource
from ovito.io import export_file


pristine_graphene = './pristine_graphene/graphene_24x24.data'
sheet_size = 24
seeds = [1861, 3407, 5127, 5276, 5465, 7190, 7320, 9148, 9194, 9409]
overlapx, overlapy = 0.05, 0.05
count = 10*10  # 6*6, 8*8, 10*10, 12*12, 14*14, 16*16 ...
vacancy_percent = 0.10  # 0.00, 0.02, 0.06, 0.10, 0.14, 0.18, 0.22, 0.26 ...

for index, seed in enumerate(seeds):
    rng = np.random.default_rng(seed=seed)
    path = './sample' + str(seed) + '/'
    if os.path.exists(path):
        shutil.rmtree(path)
    os.makedirs(path)
    data_name = [path + 'graphene' + str(i+1) + '.data' for i in range(count)]
    for i in range(count):
        atoms = np.loadtxt(pristine_graphene, skiprows=25, usecols=[2, 3, 4])
        a, size = len(atoms), math.floor(vacancy_percent*len(atoms))
        del_list = rng.choice(a=a, size=size, replace=False)
        atoms = np.delete(atoms, del_list, axis=0)

        data = DataCollection()
        particles = data.create_particles()
        pos_prop = particles.create_property('Position', data=atoms)
        type_prop = particles.create_property('Particle Type')
        type_prop.types.append(ParticleType(id=1, name='CA'))
        type_prop[...] = 1
        cell = SimulationCell(pbc=(True, True, True))
        lx, ly, _ = atoms.max(axis=0) - atoms.min(axis=0)
        o1, o2, _ = atoms.min(axis=0)
        lz = 24
        cell[...] = [[lx+1, 0, 0, o1-0.5],
                     [0, ly+1, 0, o2-0.5],
                     [0, 0, lz, -lz/2]]
        cell.vis.line_width = 0.1
        data.objects.append(cell)
        pipeline = Pipeline(source=StaticSource(data=data))
        pipeline.add_to_scene()
        export_file(pipeline, data_name[i], 'lammps/data', atom_style="atomic")

    amcs = os.listdir(path)
    size = int(np.sqrt(count))
    initial_config = []
    for amc in amcs:
        max_rows = int(np.loadtxt(path+amc, skiprows=2, max_rows=1, usecols=0))
        config = np.loadtxt(path+amc, skiprows=11, max_rows=max_rows,
                            usecols=[2, 3, 4])
        initial_config.append(config)

    n = 0
    for j in range(size):
        for k in range(size):
            initial_config[n][:, 0] += k * (sheet_size - overlapx)
            initial_config[n][:, 1] += j * (sheet_size - overlapy)
            n += 1
    initial_config = np.vstack(initial_config)

    data = DataCollection()
    particles = data.create_particles()
    pos_prop = particles.create_property('Position', data=initial_config)
    type_prop = particles.create_property('Particle Type')
    type_prop.types.append(ParticleType(id=1, name='CA'))
    type_prop[...] = 1
    cell = SimulationCell(pbc=(True, True, True))
    lx, ly, _ = initial_config.max(axis=0) - initial_config.min(axis=0)
    o1, o2, _ = initial_config.min(axis=0)
    lz = 48
    cell[...] = [[lx+0.5, 0, 0, o1-0.25],
                 [0, ly+0.5, 0, o2-0.25],
                 [0, 0, lz, -lz/2]]
    cell.vis.line_width = 0.1
    data.objects.append(cell)
    pipeline = Pipeline(source=StaticSource(data=data))
    pipeline.add_to_scene()
    saved_file = 'initial_a_G_' + str(index+1) + '.data'
    export_file(pipeline, saved_file, 'lammps/data', atom_style="atomic")
    shutil.rmtree(path)
